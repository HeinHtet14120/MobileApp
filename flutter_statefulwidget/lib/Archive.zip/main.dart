import 'package:flutter/material.dart';
import 'splash_screen.dart';

void main() {
  runApp(const MaterialApp(
    home: SplashScreen(),
  ));
}
